# AppHider - LSPosed应用隐藏模块

## 功能特性

- **系统级应用隐藏**：通过LSPosed框架实现系统级应用隐藏
- **无图标启动**：模块本身不显示应用图标
- **拨号暗号激活**：通过自定义拨号暗号打开管理界面
- **应用管理隐藏**：隐藏的应用在系统应用管理中也无法找到
- **状态栏隐藏**：隐藏的应用不会在状态栏显示通知
- **后台运行**：隐藏的应用继续在后台运行
- **多厂商支持**：支持小米、华为、OPPO、VIVO、三星等主流厂商

## 系统要求

- Android 7.0+ (API 24+)
- 已Root设备
- 已安装LSPosed框架

## 安装步骤

1. 使用Android Studio打开项目
2. 构建APK：`Build -> Build Bundle(s) / APK(s) -> Build APK(s)`
3. 将生成的APK安装到设备
4. 打开LSPosed管理器，在模块列表中找到"AppHider"
5. 勾选需要Hook的应用（系统设置、启动器等）
6. 重启设备使模块生效

## 使用说明

### 拨号暗号

默认暗号为 `1234`，可在设置中修改。

**可用命令：**

| 命令 | 说明 |
|------|------|
| `1234` | 打开应用隐藏管理界面 |
| `1234*OPEN` | 打开应用隐藏管理界面 |
| `1234*SHOW` | 显示所有隐藏的应用 |
| `1234*RESET` | 重置隐藏列表 |
| `1234*HIDE:包名` | 隐藏指定应用 |
| `1234*SHOW:包名` | 显示指定应用 |

### 管理界面

1. 通过拨号暗号打开管理界面
2. 点击应用可切换隐藏/显示状态
3. 长按应用可查看详细信息
4. 点击"设置"按钮可修改暗号和模块状态
5. 点击"刷新"按钮可重新加载应用列表

### 推荐Hook的应用

为了实现完整的隐藏效果，建议在LSPosed中勾选以下应用：

- **系统设置**：`com.android.settings`
- **启动器**：
  - 小米：`com.miui.home`
  - 华为：`com.huawei.android.launcher`
  - OPPO：`com.oppo.launcher`
  - VIVO：`com.vivo.launcher`
  - 三星：`com.sec.android.app.launcher`
  - 原生：`com.android.launcher3`
- **安全中心**：
  - 小米：`com.miui.securitycenter`
  - 华为：`com.huawei.systemmanager`
  - OPPO：`com.coloros.safecenter`
  - VIVO：`com.iqoo.secure`

## 项目结构

```
AppHiderModule/
├── app/
│   ├── src/main/
│   │   ├── java/com/apphider/
│   │   │   ├── MainHook.java              # 核心Hook逻辑
│   │   │   ├── XposedInit.java            # Xposed入口
│   │   │   ├── AppHiderApplication.java   # Application类
│   │   │   ├── receiver/
│   │   │   │   └── DialCodeReceiver.java  # 拨号暗号接收器
│   │   │   ├── service/
│   │   │   │   └── HiderService.java      # 后台服务
│   │   │   ├── ui/
│   │   │   │   ├── MainActivity.java      # 主界面
│   │   │   │   └── SettingsActivity.java  # 设置界面
│   │   │   └── utils/
│   │   │       └── PreferenceManager.java  # 偏好设置管理
│   │   ├── res/
│   │   │   ├── layout/                    # 布局文件
│   │   │   └── values/                    # 资源文件
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## 核心功能实现

### 1. 应用隐藏Hook

通过Hook `PackageManager` 的相关方法，过滤掉隐藏的应用：

- `getInstalledApplications()` - 过滤已安装应用列表
- `getInstalledPackages()` - 过滤已安装包列表
- `getApplicationInfo()` - 隐藏应用信息

### 2. 启动器Hook

Hook各厂商启动器的应用图标加载方法，隐藏应用图标。

### 3. 状态栏Hook

Hook `StatusBarManagerService`，隐藏应用的系统通知。

### 4. 最近任务Hook

Hook `ActivityManagerService`，从最近任务列表中移除隐藏的应用。

### 5. 应用管理Hook

Hook系统设置和安全中心的应用列表，在应用管理中隐藏应用。

### 6. 拨号暗号

通过 `BroadcastReceiver` 监听 `NEW_OUTGOING_CALL` 广播，检测拨号暗号。

## 注意事项

1. **Root权限**：此模块需要Root权限和LSPosed框架支持
2. **系统兼容性**：不同Android版本和厂商ROM可能需要调整Hook点
3. **稳定性**：频繁修改系统行为可能导致系统不稳定
4. **备份重要数据**：使用前请备份重要数据
5. **合法使用**：请合法使用此模块，不要用于非法用途

## 技术栈

- **开发语言**：Java
- **框架**：LSPosed (Xposed API)
- **最低SDK**：API 24 (Android 7.0)
- **目标SDK**：API 34 (Android 14)
- **构建工具**：Gradle 8.0

## 许可证

本项目仅供学习和研究使用。

## 免责声明

使用本模块所产生的一切后果由使用者自行承担，开发者不承担任何责任。
