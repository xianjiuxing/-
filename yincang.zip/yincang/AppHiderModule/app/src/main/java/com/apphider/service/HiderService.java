package com.apphider.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.apphider.MainHook;
import com.apphider.utils.PreferenceManager;

public class HiderService extends Service {
    private static final String TAG = "HiderService";
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "HiderService created");
        syncHiddenApps();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "HiderService started");
        syncHiddenApps();
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    private void syncHiddenApps() {
        java.util.Set<String> hiddenApps = PreferenceManager.getHiddenApps(this);
        for (String packageName : hiddenApps) {
            MainHook.addHiddenApp(packageName);
        }
        Log.d(TAG, "Synced " + hiddenApps.size() + " hidden apps");
    }
}
