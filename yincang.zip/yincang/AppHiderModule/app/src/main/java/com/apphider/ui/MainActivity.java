package com.apphider.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.apphider.R;
import com.apphider.utils.PreferenceManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView appListView;
    private Button btnSettings;
    private Button btnRefresh;
    private AppAdapter adapter;
    private List<AppInfo> appList;
    private PackageManager pm;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setupWindow();
        setContentView(R.layout.activity_main);
        
        pm = getPackageManager();
        appList = new ArrayList<>();
        
        initViews();
        loadApps();
        setupClickListeners();
    }
    
    private void setupWindow() {
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        getWindow().setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        );
    }
    
    private void initViews() {
        appListView = findViewById(R.id.app_list);
        btnSettings = findViewById(R.id.btn_settings);
        btnRefresh = findViewById(R.id.btn_refresh);
    }
    
    private void loadApps() {
        appList.clear();
        List<ApplicationInfo> installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        
        for (ApplicationInfo appInfo : installedApps) {
            if ((appInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                String appName = appInfo.loadLabel(pm).toString();
                String packageName = appInfo.packageName;
                boolean isHidden = PreferenceManager.isAppHidden(this, packageName);
                
                appList.add(new AppInfo(appName, packageName, appInfo, isHidden));
            }
        }
        
        Collections.sort(appList, new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo a1, AppInfo a2) {
                return a1.appName.compareToIgnoreCase(a2.appName);
            }
        });
        
        adapter = new AppAdapter(this, appList);
        appListView.setAdapter(adapter);
    }
    
    private void setupClickListeners() {
        appListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AppInfo appInfo = appList.get(position);
                toggleAppHidden(appInfo);
            }
        });
        
        appListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AppInfo appInfo = appList.get(position);
                showAppInfoDialog(appInfo);
                return true;
            }
        });
        
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettingsDialog();
            }
        });
        
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadApps();
                Toast.makeText(MainActivity.this, "已刷新", Toast.LENGTH_SHORT).show();
            }
        });
    }
    
    private void toggleAppHidden(AppInfo appInfo) {
        if (appInfo.isHidden) {
            PreferenceManager.removeHiddenApp(this, appInfo.packageName);
            appInfo.isHidden = false;
            Toast.makeText(this, "已显示: " + appInfo.appName, Toast.LENGTH_SHORT).show();
        } else {
            PreferenceManager.addHiddenApp(this, appInfo.packageName);
            appInfo.isHidden = true;
            Toast.makeText(this, "已隐藏: " + appInfo.appName, Toast.LENGTH_SHORT).show();
        }
        adapter.notifyDataSetChanged();
    }
    
    private void showAppInfoDialog(AppInfo appInfo) {
        new AlertDialog.Builder(this)
            .setTitle(appInfo.appName)
            .setMessage("包名: " + appInfo.packageName + "\n" +
                       "状态: " + (appInfo.isHidden ? "已隐藏" : "未隐藏"))
            .setPositiveButton("确定", null)
            .setNegativeButton(appInfo.isHidden ? "显示" : "隐藏", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    toggleAppHidden(appInfo);
                }
            })
            .show();
    }
    
    private void showSettingsDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null);
        
        EditText etSecretCode = dialogView.findViewById(R.id.et_secret_code);
        Switch swModuleEnabled = dialogView.findViewById(R.id.sw_module_enabled);
        Button btnClearAll = dialogView.findViewById(R.id.btn_clear_all);
        Button btnShowHelp = dialogView.findViewById(R.id.btn_show_help);
        
        etSecretCode.setText(PreferenceManager.getSecretCode(this));
        swModuleEnabled.setChecked(PreferenceManager.isModuleEnabled(this));
        
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("设置")
            .setView(dialogView)
            .setPositiveButton("保存", null)
            .setNegativeButton("取消", null)
            .create();
        
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                positiveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String code = etSecretCode.getText().toString().trim();
                        if (code.isEmpty()) {
                            Toast.makeText(MainActivity.this, "暗号不能为空", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        
                        PreferenceManager.setSecretCode(MainActivity.this, code);
                        PreferenceManager.setModuleEnabled(MainActivity.this, swModuleEnabled.isChecked());
                        
                        Toast.makeText(MainActivity.this, "设置已保存", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });
                
                btnClearAll.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        new AlertDialog.Builder(MainActivity.this)
                            .setTitle("确认")
                            .setMessage("确定要清除所有隐藏的应用吗？")
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    PreferenceManager.clearHiddenApps(MainActivity.this);
                                    loadApps();
                                    Toast.makeText(MainActivity.this, "已清除所有隐藏应用", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("取消", null)
                            .show();
                    }
                });
                
                btnShowHelp.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showHelpDialog();
                    }
                });
            }
        });
        
        dialog.show();
    }
    
    private void showHelpDialog() {
        String helpText = "拨号暗号使用说明:\n\n" +
                         "1. 拨号输入 " + PreferenceManager.getSecretCode(this) + " 打开此界面\n" +
                         "2. 拨号输入 " + PreferenceManager.getSecretCode(this) + "*OPEN 打开界面\n" +
                         "3. 拨号输入 " + PreferenceManager.getSecretCode(this) + "*SHOW 显示所有应用\n" +
                         "4. 拨号输入 " + PreferenceManager.getSecretCode(this) + "*RESET 重置隐藏列表\n" +
                         "5. 拨号输入 " + PreferenceManager.getSecretCode(this) + "*HIDE:包名 隐藏指定应用\n" +
                         "6. 拨号输入 " + PreferenceManager.getSecretCode(this) + "*SHOW:包名 显示指定应用\n\n" +
                         "注意: 需要在LSPosed中启用此模块并勾选要Hook的应用";
        
        new AlertDialog.Builder(this)
            .setTitle("使用帮助")
            .setMessage(helpText)
            .setPositiveButton("确定", null)
            .show();
    }
    
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setTitle("退出")
            .setMessage("确定要退出吗？")
            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            })
            .setNegativeButton("取消", null)
            .show();
    }
    
    static class AppInfo {
        String appName;
        String packageName;
        ApplicationInfo appInfo;
        boolean isHidden;
        
        AppInfo(String appName, String packageName, ApplicationInfo appInfo, boolean isHidden) {
            this.appName = appName;
            this.packageName = packageName;
            this.appInfo = appInfo;
            this.isHidden = isHidden;
        }
    }
    
    class AppAdapter extends ArrayAdapter<AppInfo> {
        private Context context;
        private List<AppInfo> apps;
        
        public AppAdapter(Context context, List<AppInfo> apps) {
            super(context, R.layout.item_app, apps);
            this.context = context;
            this.apps = apps;
        }
        
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
            }
            
            AppInfo app = apps.get(position);
            TextView tvAppName = convertView.findViewById(R.id.tv_app_name);
            TextView tvPackageName = convertView.findViewById(R.id.tv_package_name);
            TextView tvStatus = convertView.findViewById(R.id.tv_status);
            
            tvAppName.setText(app.appName);
            tvPackageName.setText(app.packageName);
            
            if (app.isHidden) {
                tvStatus.setText("已隐藏");
                tvStatus.setTextColor(0xFFFF0000);
            } else {
                tvStatus.setText("未隐藏");
                tvStatus.setTextColor(0xFF00FF00);
            }
            
            return convertView;
        }
    }
}
