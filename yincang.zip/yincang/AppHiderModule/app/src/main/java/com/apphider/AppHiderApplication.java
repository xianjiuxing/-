package com.apphider;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import com.apphider.utils.PreferenceManager;
import java.util.Set;

public class AppHiderApplication extends Application {
    private static final String TAG = "AppHiderApplication";
    private static Context context;
    
    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        Log.d(TAG, "AppHiderApplication created");
        initHiddenApps();
    }
    
    private void initHiddenApps() {
        Set<String> hiddenApps = PreferenceManager.getHiddenApps(this);
        Log.d(TAG, "Loaded " + hiddenApps.size() + " hidden apps from preferences");
        
        for (String packageName : hiddenApps) {
            MainHook.addHiddenApp(packageName);
        }
        
        boolean enabled = PreferenceManager.isModuleEnabled(this);
        MainHook.setModuleEnabled(enabled);
        Log.d(TAG, "Module enabled: " + enabled);
    }
    
    public static Context getContext() {
        return context;
    }
}
