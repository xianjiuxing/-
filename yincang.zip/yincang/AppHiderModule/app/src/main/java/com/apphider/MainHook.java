package com.apphider;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.util.HashSet;
import java.util.Set;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "AppHider";
    private static Set<String> hiddenApps = new HashSet<>();
    private static boolean isModuleEnabled = true;
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!isModuleEnabled) return;
        
        String packageName = lpparam.packageName;
        Log.d(TAG, "Loading package: " + packageName);
        
        hookPackageManager(lpparam);
        hookLauncher(lpparam);
        hookStatusBar(lpparam);
        hookRecentApps(lpparam);
        hookSettings(lpparam);
    }
    
    private void hookPackageManager(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod("android.app.ApplicationPackageManager", 
                lpparam.classLoader, 
                "getInstalledApplications", 
                int.class, 
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if (hiddenApps.isEmpty()) return;
                        
                        try {
                            @SuppressWarnings("unchecked")
                            java.util.List<ApplicationInfo> apps = 
                                (java.util.List<ApplicationInfo>) param.getResult();
                            
                            if (apps != null) {
                                apps.removeIf(app -> hiddenApps.contains(app.packageName));
                                param.setResult(apps);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error filtering installed apps", e);
                        }
                    }
                });
            
            XposedHelpers.findAndHookMethod("android.app.ApplicationPackageManager", 
                lpparam.classLoader, 
                "getInstalledPackages", 
                int.class, 
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if (hiddenApps.isEmpty()) return;
                        
                        try {
                            @SuppressWarnings("unchecked")
                            java.util.List<android.content.pm.PackageInfo> packages = 
                                (java.util.List<android.content.pm.PackageInfo>) param.getResult();
                            
                            if (packages != null) {
                                packages.removeIf(pkg -> hiddenApps.contains(pkg.packageName));
                                param.setResult(packages);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error filtering installed packages", e);
                        }
                    }
                });
            
            XposedHelpers.findAndHookMethod("android.app.ApplicationPackageManager", 
                lpparam.classLoader, 
                "getApplicationInfo", 
                String.class, 
                int.class, 
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        String packageName = (String) param.args[0];
                        if (hiddenApps.contains(packageName)) {
                            param.setResult(null);
                        }
                    }
                });
                
        } catch (Exception e) {
            Log.e(TAG, "Error hooking PackageManager", e);
        }
    }
    
    private void hookLauncher(XC_LoadPackage.LoadPackageParam lpparam) {
        String[] launcherPackages = {
            "com.miui.home",
            "com.android.launcher3",
            "com.huawei.android.launcher",
            "com.oppo.launcher",
            "com.vivo.launcher",
            "com.sec.android.app.launcher",
            "com.android.launcher",
            "com.bbk.launcher2"
        };
        
        for (String launcher : launcherPackages) {
            if (lpparam.packageName.equals(launcher)) {
                try {
                    XposedHelpers.findAndHookMethod("android.content.pm.PackageManager", 
                        lpparam.classLoader, 
                        "getActivityInfo", 
                        android.content.ComponentName.class, 
                        int.class, 
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                if (param.args[0] instanceof android.content.ComponentName) {
                                    android.content.ComponentName cn = 
                                        (android.content.ComponentName) param.args[0];
                                    if (hiddenApps.contains(cn.getPackageName())) {
                                        param.setResult(null);
                                    }
                                }
                            }
                        });
                } catch (Exception e) {
                    Log.e(TAG, "Error hooking launcher: " + launcher, e);
                }
            }
        }
    }
    
    private void hookStatusBar(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod("com.android.server.statusbar.StatusBarManagerService", 
                lpparam.classLoader, 
                "setNotificationIconVisibility", 
                String.class, 
                boolean.class, 
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        String packageName = (String) param.args[0];
                        if (hiddenApps.contains(packageName)) {
                            param.args[1] = false;
                        }
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "Error hooking StatusBar", e);
        }
    }
    
    private void hookRecentApps(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod("com.android.server.am.ActivityManagerService", 
                lpparam.classLoader, 
                "getTasks", 
                int.class, 
                int.class, 
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if (hiddenApps.isEmpty()) return;
                        
                        try {
                            java.util.List<?> tasks = (java.util.List<?>) param.getResult();
                            if (tasks != null) {
                                tasks.removeIf(task -> {
                                    try {
                                        String packageName = (String) XposedHelpers.getObjectField(
                                            task, "realActivity");
                                        if (packageName != null) {
                                            for (String hidden : hiddenApps) {
                                                if (packageName.contains(hidden)) {
                                                    return true;
                                                }
                                            }
                                        }
                                    } catch (Exception e) {
                                        Log.e(TAG, "Error checking task", e);
                                    }
                                    return false;
                                });
                                param.setResult(tasks);
                            }
                        } catch (Exception e) {
                            Log.e(TAG, "Error filtering recent apps", e);
                        }
                    }
                });
        } catch (Exception e) {
            Log.e(TAG, "Error hooking RecentApps", e);
        }
    }
    
    private void hookSettings(XC_LoadPackage.LoadPackageParam lpparam) {
        String[] settingsPackages = {
            "com.android.settings",
            "com.miui.securitycenter",
            "com.huawei.systemmanager",
            "com.coloros.safecenter",
            "com.iqoo.secure",
            "com.samsung.android.lool"
        };
        
        for (String settings : settingsPackages) {
            if (lpparam.packageName.equals(settings)) {
                try {
                    XposedHelpers.findAndHookMethod("android.app.ApplicationPackageManager", 
                        lpparam.classLoader, 
                        "getInstalledApplicationsAsUser", 
                        int.class, 
                        int.class, 
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                if (hiddenApps.isEmpty()) return;
                                
                                try {
                                    @SuppressWarnings("unchecked")
                                    java.util.List<ApplicationInfo> apps = 
                                        (java.util.List<ApplicationInfo>) param.getResult();
                                    
                                    if (apps != null) {
                                        apps.removeIf(app -> hiddenApps.contains(app.packageName));
                                        param.setResult(apps);
                                    }
                                } catch (Exception e) {
                                    Log.e(TAG, "Error filtering apps in settings", e);
                                }
                            }
                        });
                } catch (Exception e) {
                    Log.e(TAG, "Error hooking settings: " + settings, e);
                }
            }
        }
    }
    
    public static void addHiddenApp(String packageName) {
        hiddenApps.add(packageName);
        Log.d(TAG, "Added hidden app: " + packageName);
    }
    
    public static void removeHiddenApp(String packageName) {
        hiddenApps.remove(packageName);
        Log.d(TAG, "Removed hidden app: " + packageName);
    }
    
    public static Set<String> getHiddenApps() {
        return new HashSet<>(hiddenApps);
    }
    
    public static boolean isAppHidden(String packageName) {
        return hiddenApps.contains(packageName);
    }
    
    public static void setModuleEnabled(boolean enabled) {
        isModuleEnabled = enabled;
        Log.d(TAG, "Module enabled: " + enabled);
    }
}
