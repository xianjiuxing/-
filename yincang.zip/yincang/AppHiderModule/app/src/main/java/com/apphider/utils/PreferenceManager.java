package com.apphider.utils;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public class PreferenceManager {
    private static final String PREF_NAME = "app_hider_prefs";
    private static final String KEY_HIDDEN_APPS = "hidden_apps";
    private static final String KEY_SECRET_CODE = "secret_code";
    private static final String KEY_MODULE_ENABLED = "module_enabled";
    
    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
    
    public static void addHiddenApp(Context context, String packageName) {
        Set<String> hiddenApps = getHiddenApps(context);
        hiddenApps.add(packageName);
        getPrefs(context).edit()
            .putStringSet(KEY_HIDDEN_APPS, hiddenApps)
            .apply();
    }
    
    public static void removeHiddenApp(Context context, String packageName) {
        Set<String> hiddenApps = getHiddenApps(context);
        hiddenApps.remove(packageName);
        getPrefs(context).edit()
            .putStringSet(KEY_HIDDEN_APPS, hiddenApps)
            .apply();
    }
    
    public static Set<String> getHiddenApps(Context context) {
        Set<String> hiddenApps = getPrefs(context).getStringSet(KEY_HIDDEN_APPS, new HashSet<String>());
        return hiddenApps != null ? hiddenApps : new HashSet<String>();
    }
    
    public static void clearHiddenApps(Context context) {
        getPrefs(context).edit()
            .putStringSet(KEY_HIDDEN_APPS, new HashSet<String>())
            .apply();
    }
    
    public static boolean isAppHidden(Context context, String packageName) {
        return getHiddenApps(context).contains(packageName);
    }
    
    public static void setSecretCode(Context context, String code) {
        getPrefs(context).edit()
            .putString(KEY_SECRET_CODE, code)
            .apply();
    }
    
    public static String getSecretCode(Context context) {
        return getPrefs(context).getString(KEY_SECRET_CODE, "1234");
    }
    
    public static void setModuleEnabled(Context context, boolean enabled) {
        getPrefs(context).edit()
            .putBoolean(KEY_MODULE_ENABLED, enabled)
            .apply();
    }
    
    public static boolean isModuleEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_MODULE_ENABLED, true);
    }
}
