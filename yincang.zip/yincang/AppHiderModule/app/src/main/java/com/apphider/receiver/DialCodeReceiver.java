package com.apphider.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.apphider.ui.MainActivity;
import com.apphider.utils.PreferenceManager;

public class DialCodeReceiver extends BroadcastReceiver {
    private static final String TAG = "DialCodeReceiver";
    private static final String SECRET_CODE = "1234";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) {
            return;
        }
        
        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(intent.getAction())) {
            String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
            Log.d(TAG, "Outgoing call: " + phoneNumber);
            
            if (phoneNumber != null && phoneNumber.contains(SECRET_CODE)) {
                Log.d(TAG, "Secret code detected!");
                
                setResultData(null);
                
                String[] parts = phoneNumber.split("\\*");
                if (parts.length >= 2) {
                    String code = parts[0];
                    String action = parts.length > 1 ? parts[1] : "";
                    
                    if (code.equals(SECRET_CODE)) {
                        handleSecretCode(context, action);
                    }
                } else if (phoneNumber.equals(SECRET_CODE)) {
                    openMainActivity(context);
                }
            }
        }
    }
    
    private void handleSecretCode(Context context, String action) {
        Log.d(TAG, "Handling action: " + action);
        
        switch (action) {
            case "OPEN":
                openMainActivity(context);
                break;
            case "SHOW":
                showAllApps(context);
                break;
            case "HIDE":
                hideAllApps(context);
                break;
            case "RESET":
                resetHiddenApps(context);
                break;
            default:
                if (action.startsWith("HIDE:")) {
                    String packageName = action.substring(5);
                    hideApp(context, packageName);
                } else if (action.startsWith("SHOW:")) {
                    String packageName = action.substring(5);
                    showApp(context, packageName);
                } else {
                    openMainActivity(context);
                }
        }
    }
    
    private void openMainActivity(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("from_dialer", true);
        context.startActivity(intent);
    }
    
    private void hideApp(Context context, String packageName) {
        PreferenceManager.addHiddenApp(context, packageName);
        Log.d(TAG, "Hidden app: " + packageName);
    }
    
    private void showApp(Context context, String packageName) {
        PreferenceManager.removeHiddenApp(context, packageName);
        Log.d(TAG, "Shown app: " + packageName);
    }
    
    private void showAllApps(Context context) {
        PreferenceManager.clearHiddenApps(context);
        Log.d(TAG, "All apps shown");
    }
    
    private void hideAllApps(Context context) {
        Log.d(TAG, "Hide all apps not implemented");
    }
    
    private void resetHiddenApps(Context context) {
        PreferenceManager.clearHiddenApps(context);
        Log.d(TAG, "Hidden apps reset");
    }
}
