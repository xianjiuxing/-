package com.apphider.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.apphider.R;
import com.apphider.utils.PreferenceManager;

public class SettingsActivity extends AppCompatActivity {
    private EditText etSecretCode;
    private Switch swModuleEnabled;
    private Button btnSave;
    private Button btnClearAll;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        
        initViews();
        loadSettings();
        setupClickListeners();
    }
    
    private void initViews() {
        etSecretCode = findViewById(R.id.et_secret_code);
        swModuleEnabled = findViewById(R.id.sw_module_enabled);
        btnSave = findViewById(R.id.btn_save);
        btnClearAll = findViewById(R.id.btn_clear_all);
    }
    
    private void loadSettings() {
        etSecretCode.setText(PreferenceManager.getSecretCode(this));
        swModuleEnabled.setChecked(PreferenceManager.isModuleEnabled(this));
    }
    
    private void setupClickListeners() {
        btnSave.setOnClickListener(v -> saveSettings());
        btnClearAll.setOnClickListener(v -> clearAllHiddenApps());
    }
    
    private void saveSettings() {
        String code = etSecretCode.getText().toString().trim();
        if (code.isEmpty()) {
            Toast.makeText(this, "暗号不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        
        PreferenceManager.setSecretCode(this, code);
        PreferenceManager.setModuleEnabled(this, swModuleEnabled.isChecked());
        
        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
        finish();
    }
    
    private void clearAllHiddenApps() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("确认")
            .setMessage("确定要清除所有隐藏的应用吗？")
            .setPositiveButton("确定", (dialog, which) -> {
                PreferenceManager.clearHiddenApps(this);
                Toast.makeText(this, "已清除所有隐藏应用", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("取消", null)
            .show();
    }
}
