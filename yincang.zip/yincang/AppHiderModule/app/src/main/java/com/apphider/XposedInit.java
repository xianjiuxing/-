package com.apphider;

import android.content.Context;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_InitPackageResources;
import de.robv.android.xposed.callbacks.XC_LayoutInflated;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class XposedInit implements IXposedHookZygoteInit, IXposedHookLoadPackage {
    private static String MODULE_PATH = null;
    private static final String TAG = "AppHider";
    
    @Override
    public void initZygote(IXposedHookZygoteInit.StartupParam startupParam) throws Throwable {
        MODULE_PATH = startupParam.modulePath;
        XposedBridge.log(TAG + ": Module loaded from " + MODULE_PATH);
    }
    
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        MainHook mainHook = new MainHook();
        mainHook.handleLoadPackage(lpparam);
    }
}
